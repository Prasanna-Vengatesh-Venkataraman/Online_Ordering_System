package FinalProject;

import java.awt.*;
import java.sql.*;
import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class OrderPreview extends JFrame
{
	DB db1 = new DB();
	int y=260;
	JButton fin = new JButton("Proceed to Payment");
	JButton logout = new JButton("LOG OUT");
	String pr = null;
	
	public static void main(String[] args) 
	{
		OrderNumber abc = new OrderNumber();
		new OrderPreview(Long.toString(abc.ordernumber));		
	}
	
	public OrderPreview(String ordnum)
	{		
		setExtendedState(MAXIMIZED_BOTH);
		setResizable(false);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container cp = getContentPane();
		Action act = new Action();
		
		
		JLabel onum = new JLabel("ORDER NUMBER - ");
		onum.setBounds(50, 105, 370, 50);
		onum.setFont(new Font("Arial",Font.BOLD,40));
		onum.setForeground(Color.BLUE);
		cp.add(onum);
		
		JLabel onumval = new JLabel(ordnum);
		onumval.setBounds(420, 105, 420, 50);
		onumval.setFont(new Font("Arial",Font.BOLD,40));
		onumval.setForeground(Color.BLUE);
		cp.add(onumval);
		
		JLabel item = new JLabel("ITEM");
		item.setBounds(50, 200, 300, 50);
		item.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(item);
		
		JLabel qty = new JLabel("QUANTITY / SIZE");
		qty.setBounds(340, 200, 200, 50);
		qty.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(qty);
		
		JLabel ucost = new JLabel("COST PER UNIT");
		ucost.setBounds(590, 200, 200, 50);
		ucost.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(ucost);
		
		JLabel price = new JLabel("ITEM PRICE");
		price.setBounds(790, 200, 200, 50);
		price.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(price);
		
		fin.setBounds(1200, 750, 250, 50);
		fin.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(fin);
		fin.addActionListener(act);
		
		try 
		{
			
			String qry = "SELECT Product_Name, Quantity, Unit_Price, Price  FROM Order_Line_Number INNER JOIN Products ON Order_Line_Number.Product_ID = Products.Product_ID WHERE Order_Line_Number.Order_Number = ?";
			
			Connection c1 = db1.getConnection();
			PreparedStatement s1 = c1.prepareStatement(qry);
			s1.setString(1, ordnum);
			ResultSet rs = s1.executeQuery();
		
			while(rs.next())
			{
				JLabel a = new JLabel(rs.getString(1));
				a.setBounds(50, y, 300, 50);
				a.setFont(new Font("Arial",Font.PLAIN,20));
				cp.add(a);
				
				JLabel b = new JLabel(rs.getString(2));
				b.setBounds(420, y, 200, 50);
				b.setFont(new Font("Arial",Font.PLAIN,20));
				cp.add(b);
				
				JLabel c = new JLabel("$ "+rs.getString(3)+"0");
				c.setBounds(640, y, 150, 50);
				c.setFont(new Font("Arial",Font.PLAIN,20));
				cp.add(c);
				
				JLabel d = new JLabel("$ "+rs.getString(4)+".00");
				d.setBounds(815, y, 150, 50);
				d.setFont(new Font("Arial",Font.PLAIN,20));
				cp.add(d);
				
				y=y+50;			
			}
			
			
				String tot = "SELECT SUM(Price) FROM Order_Line_Number WHERE Order_Number = ?";
				
				PreparedStatement s2 = c1.prepareStatement(tot);
				s2.setString(1, ordnum);
				ResultSet rs2 = s2.executeQuery();
				pr = rs2.getString(1);
			
			JTextField sum = new JTextField("$"+rs2.getString(1)+".00");
			sum.setBounds(770, y+50, 150, 50);
			sum.setFont(new Font("Arial",Font.BOLD,40));
			sum.setForeground(Color.RED);
			sum.setEditable(false);
			sum.setBorder(BorderFactory.createEtchedBorder(Color.BLACK,Color.BLACK));
			cp.add(sum);
			
			JLabel totbill = new JLabel("Total");
			totbill.setBounds(620, y+50, 130, 50);
			totbill.setForeground(Color.RED);
			totbill.setFont(new Font("Arial",Font.BOLD,40));
			cp.add(totbill);
			
			c1.close();
		}
		
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
		
		logout.setBounds(1400,30,120,30);
		logout.setFont(new Font("Arial",Font.BOLD,15));
		cp.add(logout);
		logout.addActionListener(act);
		
		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/bg3.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		setVisible(true);
	}

	class Action implements ActionListener
	{	
		public void actionPerformed(ActionEvent act) 
		{
			if(act.getSource()==fin)
			{
				FinallPg a = new FinallPg();
				a.setVisible(true);
				setVisible(false);
			}
			
			if(act.getSource()==logout)
			{
				JLabel msg18= new JLabel("DO YOU WANT TO LOGOUT?");
				msg18.setFont(new Font("Arial",Font.BOLD,15));
				int lg = JOptionPane.showConfirmDialog(null, msg18,"QUESTION",JOptionPane.YES_NO_OPTION);
				
				if(lg==JOptionPane.YES_OPTION)
				{
					LoginPage lpg = new LoginPage();
					lpg.setVisible(true);
					setVisible(false);
				}
			}
		}
	}
}
