package FinalProject;

import java.awt.*;
import java.sql.*;
import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class OrderTrack extends JFrame
{
	DB db1 = new DB();
	
	JButton search = new JButton("Search");
	JButton mainpg = new JButton("Main Page");
	JTextArea onumval = new JTextArea();
	
	Container cp = getContentPane();
	int y =230;
	
	public static void main(String[] args) 
	{
		new OrderTrack();
	}

	public OrderTrack()
	{		
		setExtendedState(MAXIMIZED_BOTH);
		setResizable(false);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Action act = new Action();
		
		JLabel onum = new JLabel("ORDER NUMBER");
		onum.setBounds(50, 85, 370, 50);
		onum.setFont(new Font("Arial",Font.BOLD,40));
		onum.setForeground(Color.BLUE);
		cp.add(onum);
		
		onumval.setBounds(420, 95, 300, 30);
		onumval.setFont(new Font("Arial",Font.BOLD,25));
		cp.add(onumval);
		
		search.setBounds(750, 95, 120, 30);
		search.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(search);
		search.addActionListener(act);
		
		mainpg.setBounds(1350, 95, 140, 35);
		mainpg.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(mainpg);
		mainpg.addActionListener(act);
		
		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/bg3.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		setVisible(true);
	}
	
	class Action implements ActionListener
	{	
		public void actionPerformed(ActionEvent act) 
		{
			OrderTrack a = new OrderTrack();
			
			if(act.getSource()==search)
			{
				try
				{
					String qry = "SELECT * FROM Billing WHERE Order_No = ?";
					Connection c1 = db1.getConnection();
					PreparedStatement s1 = c1.prepareStatement(qry);
					s1.setString(1, onumval.getText());
					ResultSet rs = s1.executeQuery();
					
					JLabel fn = new JLabel(rs.getString(2));
					fn.setBounds(200, 200, 300, 30);
					fn.setFont(new Font("Arial",Font.PLAIN,25));
					a.cp.add(fn);
					
					JLabel name = new JLabel("NAME:");
					name.setBounds(100, 201, 300, 30);
					name.setFont(new Font("Arial",Font.BOLD,25));
					a.cp.add(name);
					
					
					JLabel ln = new JLabel(rs.getString(3));
					ln.setBounds(200, 230, 300, 40);
					ln.setFont(new Font("Arial",Font.PLAIN,25));
					a.cp.add(ln);
					
					JLabel addr = new JLabel("ADDRESS:");
					addr.setBounds(51, 310, 300, 30);
					addr.setFont(new Font("Arial",Font.BOLD,25));
					a.cp.add(addr);
					
					JLabel addrdb1 = new JLabel("Apt "+rs.getString(6));
					addrdb1.setBounds(200, 305, 300, 40);
					addrdb1.setFont(new Font("Arial",Font.PLAIN,25));
					a.cp.add(addrdb1);
					
					JLabel addrdb2 = new JLabel(rs.getString(7));
					addrdb2.setBounds(200, 335, 600, 40);
					addrdb2.setFont(new Font("Arial",Font.PLAIN,25));
					a.cp.add(addrdb2);
					
					JLabel addrdb3 = new JLabel(rs.getString(8));
					addrdb3.setBounds(200, 365, 300, 40);
					addrdb3.setFont(new Font("Arial",Font.PLAIN,25));
					a.cp.add(addrdb3);
					
					JLabel addrdb4 = new JLabel(rs.getString(9)+" - "+rs.getString(10));
					addrdb4.setBounds(200, 395, 300, 40);
					addrdb4.setFont(new Font("Arial",Font.PLAIN,25));
					a.cp.add(addrdb4);
					
					JLabel addrdb5 = new JLabel(rs.getString(11));
					addrdb5.setBounds(200, 425, 300, 40);
					addrdb5.setFont(new Font("Arial",Font.PLAIN,25));
					a.cp.add(addrdb5);
					
					
					JLabel mob = new JLabel("MOBILE:");
					mob.setBounds(78, 530, 300, 30);
					mob.setFont(new Font("Arial",Font.BOLD,25));
					a.cp.add(mob);
					
					JLabel mobdb = new JLabel(rs.getString(4));
					mobdb.setBounds(200, 524, 300, 40);
					mobdb.setFont(new Font("Arial",Font.PLAIN,25));
					a.cp.add(mobdb);
					
					JLabel email = new JLabel("EMAIL:");
					email.setBounds(96, 600, 300, 30);
					email.setFont(new Font("Arial",Font.BOLD,25));
					a.cp.add(email);
					
					JLabel emaildb = new JLabel(rs.getString(5));
					emaildb.setBounds(200, 592, 500, 40);
					emaildb.setFont(new Font("Arial",Font.PLAIN,25));
					a.cp.add(emaildb);
					
					JLabel total = new JLabel("AMOUNT:");
					total.setBounds(65, 665, 300, 30);
					total.setFont(new Font("Arial",Font.BOLD,25));
					a.cp.add(total);
					
					JLabel totaldb = new JLabel("$"+rs.getString(12)+".00");
					totaldb.setBounds(200, 661, 500, 40);
					totaldb.setFont(new Font("Arial",Font.PLAIN,25));
					a.cp.add(totaldb);
					
					JLabel pay = new JLabel("PAYMENT:");
					pay.setBounds(53, 730, 300, 30);
					pay.setFont(new Font("Arial",Font.BOLD,25));
					a.cp.add(pay);
					
					JLabel paydb = new JLabel(rs.getString(13));
					paydb.setBounds(200, 724, 300, 40);
					paydb.setFont(new Font("Arial",Font.PLAIN,25));
					a.cp.add(paydb);
					
					JLabel item = new JLabel("ITEM");
					item.setBounds(620, 201, 300, 30);
					item.setFont(new Font("Arial",Font.BOLD,25));
					a.cp.add(item);
					
					JLabel qty = new JLabel("QUANTITY/SIZE");
					qty.setBounds(810, 201, 300, 30);
					qty.setFont(new Font("Arial",Font.BOLD,25));
					a.cp.add(qty);
					
					
					String qry2 = "SELECT Product_Name, Quantity FROM Order_Line_Number INNER JOIN Products ON Order_Line_Number.Product_ID = Products.Product_ID WHERE Order_Line_Number.Order_Number = ?";
					PreparedStatement s2 = c1.prepareStatement(qry2);
					s2.setString(1, onumval.getText());
					ResultSet rs2 = s2.executeQuery();
					
					while(rs2.next())
					{

						JLabel x1 = new JLabel(rs2.getString(1));
						x1.setBounds(620, y, 300, 50);
						x1.setFont(new Font("Arial",Font.PLAIN,20));
						a.cp.add(x1);
						
						JLabel x2 = new JLabel(rs2.getString(2));
						x2.setBounds(900, y, 50, 50);
						x2.setFont(new Font("Arial",Font.PLAIN,20));
						a.cp.add(x2);
						
						y=y+60;
					}
					
					a.cp.setLayout(new BorderLayout());
					
					ImageIcon bg = new ImageIcon("src/bg3.jpg");
					JLabel background = new JLabel(bg);
					a.cp.add(background);
				}
				
				catch (SQLException e)
				{
					
					ImageIcon bg = new ImageIcon("src/bg3.jpg");
					JLabel background = new JLabel(bg);
					a.cp.add(background);
					
					JLabel nomat = new JLabel("Sorry, No matches for Order Number "+onumval.getText());
					nomat.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,nomat,"Error",JOptionPane.ERROR_MESSAGE);
					setVisible(false);
					
				}
			}
			
			if(act.getSource()==mainpg)
			{
				LoginPage lp = new LoginPage();
				lp.setVisible(true);
				setVisible(false);
			}
		}
	}
}
