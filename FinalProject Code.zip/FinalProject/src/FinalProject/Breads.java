package FinalProject;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Breads extends JFrame
{
	DB db1 = new DB();
	OrderNumber abc = new OrderNumber();
	
	JButton continuebtn = new JButton("Continue");
	JButton checkoutbtn = new JButton("Checkout");
	JButton logout = new JButton("LOG OUT");

	JTextArea b1ta = new JTextArea("0");
	JTextArea b2ta = new JTextArea("0");
	JTextArea b3ta = new JTextArea("0");

	JButton b1sub = new JButton("-");
	JButton b2sub = new JButton("-");
	JButton b3sub = new JButton("-");

	JButton b1add = new JButton("+");
	JButton b2add = new JButton("+");
	JButton b3add = new JButton("+");

	
	public Breads()
	{
		setExtendedState(MAXIMIZED_BOTH);
		setResizable(false);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container cp = getContentPane();
		Action act = new Action();
		
		JLabel title = new JLabel("BREADS");
		title.setFont(new Font("Lucida Calligraphy",Font.ITALIC,80));
		title.setForeground(Color.GREEN);
		title.setBounds(550,0,1100,150);
		cp.add(title);
		
		JLabel qty = new JLabel("QUANTITY");
		qty.setBounds(25, 475, 170, 50);
		qty.setFont(new Font("Arial",Font.BOLD,30));
		cp.add(qty);
		
		JLabel bread1name = new JLabel("CROISSANT");
		bread1name.setBounds(310, 170, 250, 20);
		bread1name.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(bread1name);
		
		ImageIcon img = new ImageIcon("src/bread1.jpg");
		JLabel bread1 = new JLabel(img);
		bread1.setBounds(220, 200, 300, 225);
		cp.add(bread1);
		
		
		b1ta.setEditable(false);
		b1ta.setBounds(350, 470, 50, 50);
		b1ta.setFont(new Font("Arial",Font.BOLD,45));
		cp.add(b1ta);
		
		b1sub.setBounds(280, 470, 50, 50);
		b1sub.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(b1sub);
		b1sub.addActionListener(act);
		
		b1add.setBounds(420, 470, 50, 50);
		b1add.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(b1add);
		b1add.addActionListener(act);
		
		
		JLabel bread2name = new JLabel("GLAZED DONUT");
		bread2name.setBounds(695, 170, 300, 20);
		bread2name.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(bread2name);
		
		ImageIcon img2 = new ImageIcon("src/bread2.jpg");
		JLabel bread2 = new JLabel(img2);
		bread2.setBounds(620, 200, 300, 225);
		cp.add(bread2);

		b2ta.setEditable(false);
		b2ta.setBounds(755, 470, 50, 50);
		b2ta.setFont(new Font("Arial",Font.BOLD,45));
		cp.add(b2ta);
		
		b2sub.setBounds(685, 470, 50, 50);
		b2sub.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(b2sub);
		b2sub.addActionListener(act);
		
		b2add.setBounds(825, 470, 50, 50);
		b2add.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(b2add);
		b2add.addActionListener(act);
		
		JLabel pastry3name = new JLabel("BREAD LOAF");
		pastry3name.setBounds(1100, 170, 300, 20);
		pastry3name.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(pastry3name);
		
		ImageIcon img3 = new ImageIcon("src/bread3.jpeg");
		JLabel pastry3 = new JLabel(img3);
		pastry3.setBounds(1020, 200, 300, 225);
		cp.add(pastry3);
		
		b3ta.setEditable(false);
		b3ta.setBounds(1155, 470, 50, 50);
		b3ta.setFont(new Font("Arial",Font.BOLD,45));
		cp.add(b3ta);
		
		b3sub.setBounds(1085, 470, 50, 50);
		b3sub.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(b3sub);
		b3sub.addActionListener(act);
		
		b3add.setBounds(1225, 470, 50, 50);
		b3add.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(b3add);
		b3add.addActionListener(act);
		
		continuebtn.setBounds(1300, 700, 150, 40);
		continuebtn.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(continuebtn);
		continuebtn.addActionListener(act);
		
		checkoutbtn.setBounds(1300, 760, 150, 40);
		checkoutbtn.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(checkoutbtn);
		checkoutbtn.addActionListener(act);
		
		logout.setBounds(1400,30,120,30);
		logout.setFont(new Font("Arial",Font.BOLD,15));
		cp.add(logout);
		logout.addActionListener(act);

		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/bg.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		setVisible(true);
		
	}
	
	class Action implements ActionListener
	{	
		public void actionPerformed(ActionEvent act) 
		{
			if (act.getSource()==continuebtn)
			{	
				DBVal a2 = new DBVal();
				a2.OrderInfo(b1ta, "B1"); a2.OrderInfo(b2ta, "B2"); a2.OrderInfo(b3ta, "B3");
				
				Menu a = new Menu();
				a.setVisible(true);
				setVisible(false);
			}
			
			if (act.getSource()==checkoutbtn)
			{
				DBVal a2 = new DBVal();
				a2.OrderInfo(b1ta, "B1"); a2.OrderInfo(b2ta, "B2"); a2.OrderInfo(b3ta, "B3");
				
				OrderPreview a3 = new OrderPreview(Long.toString(abc.ordernumber));
				a3.setVisible(true);
				setVisible(false);
			}
			
			if(act.getSource()==logout)
			{
				JLabel msg18= new JLabel("DO YOU WANT TO LOGOUT?");
				msg18.setFont(new Font("Arial",Font.BOLD,15));
				int lg = JOptionPane.showConfirmDialog(null, msg18,"QUESTION",JOptionPane.YES_NO_OPTION);
				
				if(lg==JOptionPane.YES_OPTION)
				{
					LoginPage lpg = new LoginPage();
					lpg.setVisible(true);
					setVisible(false);
				}
			}
			
			if(act.getSource()==b1add)
				add(b1ta);
			if(act.getSource()==b2add)
				add(b2ta);
			if(act.getSource()==b3add)
				add(b3ta);
			
			if(act.getSource()==b1sub)
				sub(b1ta);
			if(act.getSource()==b2sub)
				sub(b2ta);
			if(act.getSource()==b3sub)
				sub(b3ta);
		}
	}
	
	void add(JTextArea ta)
	{
		int a = Integer.parseInt(ta.getText());
		a++;
		ta.setText(Integer.toString(a));
	}
	
	void sub(JTextArea ta)
	{
		int a = Integer.parseInt(ta.getText());
		if(a==0)
		{
			JLabel msg11= new JLabel("Value already at 0");
			msg11.setFont(new Font("Arial",Font.BOLD,15));
			JOptionPane.showMessageDialog(null,msg11,"Error",JOptionPane.ERROR_MESSAGE);
		}
		else
		{
			a--;
			ta.setText(Integer.toString(a));
		}
	}
	
	public static void main(String[] args) 
	{
		new Breads();
	}

}
