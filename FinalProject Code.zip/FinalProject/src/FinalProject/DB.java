package FinalProject;

import java.sql.*;
import javax.swing.*;

public class DB 
{
	public static void main(String[] args) 
	{
		DB a = new DB();
		try 
		{
			Connection c1 = a.getConnection();
		}
		
		catch(SQLException e)
		{
			System.out.println("\nSQL Failed\n"+e.getMessage());
		}
	}

	public Connection getConnection() throws SQLException
	{
		String dburl = "jdbc:sqlite:C:/UIC/First Sem/IDS 401 - Business Object Programming using Java/SQLiteStudio/Final";
		Connection connect = DriverManager.getConnection(dburl);
		return connect;
	}

}