package FinalProject;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Menu extends JFrame
{

	JButton cakesbtn = new JButton("PLACE ORDER");
	JButton pastriesbtn = new JButton("PLACE ORDER");
	JButton breadsbtn = new JButton("PLACE ORDER");
	JButton logout = new JButton("LOG OUT");
	
	public static void main(String[] args) 
	{
		new Menu();
	}

	public Menu()
	{
		setExtendedState(MAXIMIZED_BOTH);
		setResizable(false);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container cp = getContentPane();
		Action act = new Action();
		ButtonGroup rb = new ButtonGroup();
		
		JLabel title = new JLabel("Welcome to PANS Cake Shop");
		title.setFont(new Font("Lucida Calligraphy",Font.ITALIC,80));
		title.setForeground(Color.RED);
		title.setBounds(110,5,1300,115);
		cp.add(title);
		
		JLabel cakes = new JLabel("CAKES");
		cakes.setBounds(180, 160, 200, 40);
		cakes.setFont(new Font("Arial",Font.BOLD,25));
		cp.add(cakes);
		
		ImageIcon cakesimg = new ImageIcon("src/cakesopt.jpg");
		JLabel lcakesimg = new JLabel(cakesimg);
		lcakesimg.setBounds(80, 200, 300, 300);
		cp.add(lcakesimg);
		
		
		cakesbtn.setBounds(155, 520, 150, 30);
		cakesbtn.setFont(new Font("Arial",Font.BOLD,15));
		cp.add(cakesbtn);
		cakesbtn.addActionListener(act);
		
		JLabel pastries = new JLabel("PASTRIES");
		pastries.setBounds(720, 160, 200, 40);
		pastries.setFont(new Font("Arial",Font.BOLD,25));
		cp.add(pastries);
		
		ImageIcon pastriesimg = new ImageIcon("src/Pastriesopt.jpg");
		JLabel lpastriesimg = new JLabel(pastriesimg);
		lpastriesimg.setBounds(630, 200, 300, 300);
		cp.add(lpastriesimg);
		
		
		pastriesbtn.setBounds(705, 520, 150, 30);
		pastriesbtn.setFont(new Font("Arial",Font.BOLD,15));
		cp.add(pastriesbtn);
		pastriesbtn.addActionListener(act);
		
		JLabel breads = new JLabel("BREADS");
		breads.setBounds(1280, 160, 200, 40);
		breads.setFont(new Font("Arial",Font.BOLD,25));
		cp.add(breads);
		
		ImageIcon breadsimg = new ImageIcon("src/Breadsopt.jpg");
		JLabel lbreadsimg = new JLabel(breadsimg);
		lbreadsimg.setBounds(1180, 200, 300, 300);
		cp.add(lbreadsimg);
		
		
		breadsbtn.setBounds(1255, 520, 150, 30);
		breadsbtn.setFont(new Font("Arial",Font.BOLD,15));
		cp.add(breadsbtn);
		breadsbtn.addActionListener(act);
		
		logout.setBounds(1400,30,120,30);
		logout.setFont(new Font("Arial",Font.BOLD,15));
		cp.add(logout);
		logout.addActionListener(act);
		
		
		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/bg5.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		setVisible(true);
		
	}
	
	class Action implements ActionListener
	{
		
		public void actionPerformed(ActionEvent act) 
		{
			if (act.getSource()== cakesbtn)
			{
				Cakes a = new Cakes();
				a.setVisible(true);
				setVisible(false);
			}
			
			if (act.getSource()== pastriesbtn)
			{
				Pastries b = new Pastries();
				b.setVisible(true);
				setVisible(false);
			}
			
			if (act.getSource()== breadsbtn)
			{
				Breads c = new Breads();
				c.setVisible(true);
				setVisible(false);
			}
			
			if(act.getSource()==logout)
			{
				JLabel msg18= new JLabel("DO YOU WANT TO LOGOUT?");
				msg18.setFont(new Font("Arial",Font.BOLD,15));
				int lg = JOptionPane.showConfirmDialog(null, msg18,"QUESTION",JOptionPane.YES_NO_OPTION);
				
				if(lg==JOptionPane.YES_OPTION)
				{
					LoginPage lpg = new LoginPage();
					lpg.setVisible(true);
					setVisible(false);
				}
			}
		}
		
	}
}