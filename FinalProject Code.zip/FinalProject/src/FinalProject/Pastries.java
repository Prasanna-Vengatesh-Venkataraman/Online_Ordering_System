package FinalProject;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Pastries extends JFrame
{
	DB db1 = new DB();
	OrderNumber abc = new OrderNumber();
	
	JButton continuebtn = new JButton("Continue");
	JButton checkoutbtn = new JButton("Checkout");
	JButton logout = new JButton("LOG OUT");
	
	JTextArea p1ta = new JTextArea("0");
	JTextArea p2ta = new JTextArea("0");
	JTextArea p3ta = new JTextArea("0");

	JButton p1sub = new JButton("-");
	JButton p2sub = new JButton("-");
	JButton p3sub = new JButton("-");

	JButton p1add = new JButton("+");
	JButton p2add = new JButton("+");
	JButton p3add = new JButton("+");

	
	public Pastries()
	{
		setExtendedState(MAXIMIZED_BOTH);
		setResizable(false);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container cp = getContentPane();
		Action act = new Action();
		
		JLabel title = new JLabel("PASTRIES");
		title.setFont(new Font("Lucida Calligraphy",Font.ITALIC,80));
		title.setForeground(Color.RED);
		title.setBounds(530,0,1100,150);
		cp.add(title);
		
		JLabel qty = new JLabel("QUANTITY");
		qty.setBounds(25, 475, 170, 50);
		qty.setFont(new Font("Arial",Font.BOLD,30));
		cp.add(qty);
		
		JLabel pastry1name = new JLabel("CUP CAKE");
		pastry1name.setBounds(320, 170, 250, 20);
		pastry1name.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(pastry1name);
		
		ImageIcon img = new ImageIcon("src/pastry1.jpg");
		JLabel pastry1 = new JLabel(img);
		pastry1.setBounds(220, 200, 300, 225);
		cp.add(pastry1);
				
		p1ta.setEditable(false);
		p1ta.setBounds(350, 470, 50, 50);
		p1ta.setFont(new Font("Arial",Font.BOLD,45));
		cp.add(p1ta);
		
		p1sub.setBounds(280, 470, 50, 50);
		p1sub.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(p1sub);
		p1sub.addActionListener(act);
		
		p1add.setBounds(420, 470, 50, 50);
		p1add.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(p1add);
		p1add.addActionListener(act);
		
		JLabel pastry2name = new JLabel("M&M BROWNIE");
		pastry2name.setBounds(705, 170, 300, 20);
		pastry2name.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(pastry2name);
		
		ImageIcon img2 = new ImageIcon("src/pastry2.jpg");
		JLabel pastry2 = new JLabel(img2);
		pastry2.setBounds(620, 200, 300, 225);
		cp.add(pastry2);

		p2ta.setEditable(false);
		p2ta.setBounds(755, 470, 50, 50);
		p2ta.setFont(new Font("Arial",Font.BOLD,45));
		cp.add(p2ta);
		
		p2sub.setBounds(685, 470, 50, 50);
		p2sub.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(p2sub);
		p2sub.addActionListener(act);
		
		p2add.setBounds(825, 470, 50, 50);
		p2add.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(p2add);
		p2add.addActionListener(act);

		JLabel pastry3name = new JLabel("CHOCO LAVA CAKE");
		pastry3name.setBounds(1080, 170, 300, 20);
		pastry3name.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(pastry3name);
		
		ImageIcon img3 = new ImageIcon("src/pastry3.jpg");
		JLabel pastry3 = new JLabel(img3);
		pastry3.setBounds(1020, 200, 300, 225);
		cp.add(pastry3);
		
		p3ta.setEditable(false);
		p3ta.setBounds(1155, 470, 50, 50);
		p3ta.setFont(new Font("Arial",Font.BOLD,45));
		cp.add(p3ta);
		
		p3sub.setBounds(1085, 470, 50, 50);
		p3sub.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(p3sub);
		p3sub.addActionListener(act);
		
		p3add.setBounds(1225, 470, 50, 50);
		p3add.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(p3add);
		p3add.addActionListener(act);
				
		continuebtn.setBounds(1300, 700, 150, 40);
		continuebtn.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(continuebtn);
		continuebtn.addActionListener(act);
		
		checkoutbtn.setBounds(1300, 760, 150, 40);
		checkoutbtn.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(checkoutbtn);
		checkoutbtn.addActionListener(act);
		
		logout.setBounds(1400,30,120,30);
		logout.setFont(new Font("Arial",Font.BOLD,15));
		cp.add(logout);
		logout.addActionListener(act);

		
		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/bg.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		setVisible(true);		
	}
	
	class Action implements ActionListener
	{	
		public void actionPerformed(ActionEvent act) 
		{
			if (act.getSource()==continuebtn)
			{
				DBVal a2 = new DBVal();
				a2.OrderInfo(p1ta, "P1"); a2.OrderInfo(p2ta, "P2"); a2.OrderInfo(p3ta, "P3");
				Menu a = new Menu();
				a.setVisible(true);
				setVisible(false);
			}
			
			if (act.getSource()==checkoutbtn)
			{
				DBVal a2 = new DBVal();
				a2.OrderInfo(p1ta, "P1"); a2.OrderInfo(p2ta, "P2"); a2.OrderInfo(p3ta, "P3");
				
				OrderPreview a3 = new OrderPreview(Long.toString(abc.ordernumber));
				a3.setVisible(true);
				setVisible(false);
			}
			
			if(act.getSource()==logout)
			{
				JLabel msg19= new JLabel("DO YOU WANT TO LOGOUT?");
				msg19.setFont(new Font("Arial",Font.BOLD,15));
				int lg = JOptionPane.showConfirmDialog(null, msg19,"QUESTION",JOptionPane.YES_NO_OPTION);
				
				if(lg==JOptionPane.YES_OPTION)
				{
					LoginPage lpg = new LoginPage();
					lpg.setVisible(true);
					setVisible(false);
				}
			}
			
			if(act.getSource()==p1add)
				add(p1ta);
			if(act.getSource()==p2add)
				add(p2ta);
			if(act.getSource()==p3add)
				add(p3ta);
			
			if(act.getSource()==p1sub)
				sub(p1ta);
			if(act.getSource()==p2sub)
				sub(p2ta);
			if(act.getSource()==p3sub)
				sub(p3ta);
		}
		
	}
	
	void add(JTextArea ta)
	{
		int a = Integer.parseInt(ta.getText());
		a++;
		ta.setText(Integer.toString(a));
	}
	
	void sub(JTextArea ta)
	{
		int a = Integer.parseInt(ta.getText());
		if(a==0)
		{
			JLabel msg17= new JLabel("CANNOT REDUCE BEYOND 0");
			msg17.setFont(new Font("Arial",Font.BOLD,15));
			JOptionPane.showMessageDialog(null,msg17,"Error",JOptionPane.ERROR_MESSAGE);
		}
		else
		{
			a--;
			ta.setText(Integer.toString(a));
		}
	}
	
	public static void main(String[] args) 
	{
		new Pastries();
	}

}
