package FinalProject;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import javax.swing.*;

public class DBVal 
{
	DB db1 = new DB();

	public static void main(String[] args) 
	{
		
	}
	
	public void OrderInfo(JTextArea ta, String pid)
	{
		try
		{
			if(Integer.parseInt(ta.getText())!=0)
			{
				Double price = null;
				OrderNumber abc = new OrderNumber();
				
				String qry2 = "SELECT Unit_Price FROM Products WHERE Product_ID = ?";
				Connection c2 = db1.getConnection();
				PreparedStatement s2 = c2.prepareStatement(qry2);
				s2.setString(1, pid);
				ResultSet rs2 = s2.executeQuery();
				
				while(rs2.next())
				{
					price = Double.parseDouble(ta.getText()) * Double.parseDouble(rs2.getString(1));
				}
				
				String qry = "INSERT INTO Order_Line_Number (Order_Number, Product_ID, Quantity, Price) VALUES (?,?,?,?)";
				Connection c1 = db1.getConnection();
				PreparedStatement s1 = c1.prepareStatement(qry);
				s1.setString(1, Long.toString(abc.ordernumber));
				s1.setString(4, Double.toString(price));
				s1.setString(2, pid);
				s1.setString(3, ta.getText());
				int rs = s1.executeUpdate();
				
			}
		}
		
		catch(SQLException e)
		{
			e.getMessage();
		}
	}
	
	public void OrderInfo(JComboBox cb, String sid)
	{
		try
		{
			if(cb.getSelectedItem()!= "0")
			{
				Double price = null;
				OrderNumber abc = new OrderNumber();
				
				String qry2 = "SELECT Unit_Price FROM Products WHERE Product_ID = ?";
				Connection c2 = db1.getConnection();
				PreparedStatement s2 = c2.prepareStatement(qry2);
				s2.setString(1, sid);
				ResultSet rs2 = s2.executeQuery();
				
				while(rs2.next())
				{
					price = Double.parseDouble((String) cb.getSelectedItem()) * Double.parseDouble(rs2.getString(1));
				}
				
				String qry = "INSERT INTO Order_Line_Number (Order_Number, Product_ID, Quantity, Price) VALUES (?,?,?,?)";
				Connection c1 = db1.getConnection();
				PreparedStatement s1 = c1.prepareStatement(qry);
				s1.setString(1, Long.toString(abc.ordernumber));
				s1.setString(4, Double.toString(price));
				s1.setString(2, sid);
				s1.setString(3, (String) cb.getSelectedItem());
				int rs = s1.executeUpdate();
				
			}
		}
		
		catch(SQLException e)
		{
			e.getMessage();
		}
	}

}
