package FinalProject;

import java.awt.*;
import java.sql.*;
import java.time.*;
import javax.swing.*;
import java.time.format.DateTimeFormatter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CreateAccount extends JFrame
{
	DB db1 = new DB();
	
	JButton signup = new JButton("SIGN UP");
	JButton cancel = new JButton("CANCEL");
	
	JPasswordField pwdpf = new JPasswordField();
	JPasswordField rtpwdpf = new JPasswordField();
	
	JCheckBox sp = new JCheckBox("SHOW PASSWORD");
	
	JTextField nametf = new JTextField();
	JTextField emailtf = new JTextField();
	JTextField uidtf = new JTextField();
	
	public CreateAccount()
	{
		setExtendedState(MAXIMIZED_BOTH);
		setResizable(false);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container cp = getContentPane();
		Action act = new Action();
		
		
		JLabel fttitle = new JLabel("New User Details");
		fttitle.setBounds(490, 180, 700, 100);
		fttitle.setFont(new Font("Lucida Calligraphy",Font.BOLD,60));
		fttitle.setForeground(Color.WHITE);
		cp.add(fttitle);
		
		JLabel name = new JLabel("User Name");
		name.setBounds(510, 280, 200, 50);
		name.setFont(new Font("Times New Roman",Font.BOLD,30));
		name.setForeground(Color.WHITE);
		cp.add(name);
		
		nametf.setBounds(780, 285, 300, 30);
		nametf.setFont(new Font("Times New Roman",Font.BOLD,30));
		cp.add(nametf);
		
		JLabel uid = new JLabel("User ID");
		uid.setBounds(510, 350, 200, 50);
		uid.setFont(new Font("Times New Roman",Font.BOLD,30));
		uid.setForeground(Color.WHITE);
		cp.add(uid);
		
		uidtf.setBounds(780, 355, 300, 30);
		uidtf.setFont(new Font("Times New Roman",Font.BOLD,30));
		cp.add(uidtf);
		
		JLabel email = new JLabel("Email ID");
		email.setBounds(510, 420, 200, 50);
		email.setFont(new Font("Times New Roman",Font.BOLD,30));
		email.setForeground(Color.WHITE);
		cp.add(email);
		
		emailtf.setBounds(780, 425, 300, 30);
		emailtf.setFont(new Font("Times New Roman",Font.BOLD,30));
		cp.add(emailtf);
		
		JLabel pwd = new JLabel("Password");
		pwd.setBounds(510, 490, 200, 50);
		pwd.setFont(new Font("Times New Roman",Font.BOLD,30));
		pwd.setForeground(Color.WHITE);
		cp.add(pwd);
		
		
		pwdpf.setBounds(780, 495, 300, 30);
		pwdpf.setFont(new Font("Times New Roman",Font.BOLD,30));
		cp.add(pwdpf);
		
		JLabel rtpwd = new JLabel("Re-type Password");
		rtpwd.setBounds(510, 560, 250, 50);
		rtpwd.setFont(new Font("Times New Roman",Font.BOLD,30));
		rtpwd.setForeground(Color.WHITE);
		cp.add(rtpwd);
		
		rtpwdpf.setBounds(780, 565, 300, 30);
		rtpwdpf.setFont(new Font("Times New Roman",Font.BOLD,30));
		cp.add(rtpwdpf);
		
		sp.setBounds(1100, 495,165,30);
		sp.setOpaque(true);
		sp.setBackground(Color.BLACK);
		sp.setFont(new Font("Times New Roman",Font.BOLD,15));
		sp.setForeground(Color.WHITE);
		cp.add(sp);
		sp.addActionListener(act);

		
		signup.setBounds(610, 650, 150, 30);
		signup.setFont(new Font("Times New Roman",Font.BOLD,20));
		cp.add(signup);
		signup.addActionListener(act);
		
		cancel.setBounds(830, 650, 150, 30);
		cancel.setFont(new Font("Times New Roman",Font.BOLD,20));
		cp.add(cancel);
		cancel.addActionListener(act);
		
		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/loginimg.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		setVisible(true);

	}
	
	class Action implements ActionListener
	{
		public void actionPerformed(ActionEvent act) 
		{
			if(act.getSource()==signup)
			{
				int count1=0, count2=0, count3=0, count4=0, count5=0;
				String a1 = nametf.getText(), a2=uidtf.getText(), a3=emailtf.getText(), a4=pwdpf.getText(), a5=rtpwdpf.getText();
				
				for(int i=0; i<a1.length();i++)
				{
					if(a1.charAt(i) == ' ')
						count1++;
				}
				
				for(int i=0; i<a2.length();i++)
				{
					if(a2.charAt(i) == ' ')
						count2++;
				}
				
				for(int i=0; i<a3.length();i++)
				{
					if(a3.charAt(i) == ' ')
						count3++;
				}
				
				for(int i=0; i<a4.length();i++)
				{
					if(a4.charAt(i) == ' ')
						count4++;
				}
				
				for(int i=0; i<a5.length();i++)
				{
					if(a5.charAt(i) == ' ')
						count5++;
				}
				
				if(count1==a1.length() || a1.length()==0)
				{
					JLabel msg12= new JLabel("USER NAME MISSING. PLEASE PROVIDE A USER NAME");
					msg12.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg12,"ERROR",JOptionPane.ERROR_MESSAGE);
					nametf.setText("");
				}
				
				else if(count2==a2.length() || a2.length()==0)
				{
					JLabel msg13= new JLabel("USERID MISSING. PLEASE PROVIDE A USER ID");
					msg13.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg13,"ERROR",JOptionPane.ERROR_MESSAGE);
					uidtf.setText("");
				}
				
				else if(count3==a3.length() || a3.length()==0)
				{
					JLabel msg14= new JLabel("EMAIL MISSING. PLEASE PROVIDE AN EMAIl ADDRESS");
					msg14.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg14,"ERROR",JOptionPane.ERROR_MESSAGE);
					emailtf.setText("");
				}
				
				else if(EmailValidation(a3)==false)
				{
					JLabel msg14= new JLabel("EMAIL ADDRESS IS INVALID. PLEASE PROVIDE A VALID EMAIL ADDRESS");
					msg14.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg14,"ERROR",JOptionPane.ERROR_MESSAGE);
					emailtf.setText("");
				}
				
				else if(a4.compareTo(a5) == 0 && a4.length() != 0 && count4 != a4.length() && EmailValidation(a3)==true)
				{
					try
					{
						String qry = "INSERT INTO Authorisation (UserID,Password,User_Name,Email_ID) VALUES(?,?,?,?)";
						Connection c1 = db1.getConnection();
						PreparedStatement s1 = c1.prepareStatement(qry);
						s1.setString(1, uidtf.getText());
						s1.setString(2, pwdpf.getText());
						s1.setString(3, nametf.getText());
						s1.setString(4, emailtf.getText());
						int rs = s1.executeUpdate();
					}
					
					catch(SQLException e)
					{
						System.out.println(e.getMessage());
					}
					
					JLabel msg15= new JLabel("SIGN UP COMPLETE. THANK YOU");
					msg15.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg15,"SUCCESS",JOptionPane.INFORMATION_MESSAGE);
				
					LoginPage lp = new LoginPage();
					lp.setVisible(true);
					setVisible(false);
				}
				
				else
				{
					JLabel msg16= new JLabel("PASSWORD MISMATCH. PLEASE RE-ENTER PASSWORD");
					msg16.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg16,"ERROR",JOptionPane.ERROR_MESSAGE);
					pwdpf.setText("");
					rtpwdpf.setText("");
				}
			}
			
			if(act.getSource()==cancel)
			{	
				LoginPage a = new LoginPage();
				a.setVisible(true);
				setVisible(false);
			}
			
			if(act.getSource()==sp)
			{
				if(sp.isSelected())
				{
					pwdpf.setEchoChar((char)0);
				}
				else
				{
					pwdpf.setEchoChar('�');
				}
			}

		}
	}
	
	public static void main(String[] args) 
	{
		new CreateAccount();
	}
	
	static boolean EmailValidation(String a)
	{
		String emailsyntax = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		return a.matches(emailsyntax);
	}

}
