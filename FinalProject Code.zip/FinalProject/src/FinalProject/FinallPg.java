package FinalProject;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FinallPg extends JFrame
{
	DB db2 = new DB();
	OrderNumber abc = new OrderNumber();
	String payopt = null;
	ButtonGroup pdbg = new ButtonGroup();
	OrderPreview op = new OrderPreview(Long.toString(abc.ordernumber));
	
	JTextArea fnta = new JTextArea();
	JTextArea lnta = new JTextArea();
	JTextArea mobta = new JTextArea();
	JTextArea emailta = new JTextArea();
	JTextArea aptta = new JTextArea();
	JTextArea stta = new JTextArea();
	JTextArea cityta = new JTextArea();
	JTextArea stateta = new JTextArea();
	JTextArea zcta = new JTextArea();
	JTextArea countryta = new JTextArea();
	
	JRadioButton cc = new JRadioButton("Credit Card");
	JRadioButton dc = new JRadioButton("Debit Card");
	JRadioButton ppl = new JRadioButton("PayPal");
	JRadioButton cod = new JRadioButton("Cash On Delivery");
	
	JButton po = new JButton("Place Order"); 
	JButton logout = new JButton("LOG OUT");
	
	public static void main(String[] args)
	{
		new FinallPg(); 
	}
	
	static boolean EmailValidation(String a)
	{
		String emailsyntax = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		return a.matches(emailsyntax);
	}
	
	public FinallPg()
	{
		setExtendedState(MAXIMIZED_BOTH);
		setResizable(false);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container cp = getContentPane();
		Action act = new Action();
		
		JLabel cust = new JLabel("CUSTOMER DETAILS");
		cust.setBounds(160, 30, 520, 40);
		cust.setFont(new Font("Arial", Font.BOLD,40));
		cust.setForeground(Color.WHITE);
		cp.add(cust);
		
		JLabel adr = new JLabel("ADDRESS DETAILS");
		adr.setBounds(930, 30, 520, 40);
		adr.setFont(new Font("Arial", Font.BOLD,40));
		adr.setForeground(Color.WHITE);
		cp.add(adr);
		
		JLabel pd = new JLabel("PAYMENT OPTION");
		pd.setBounds(930, 470, 520, 40);
		pd.setFont(new Font("Arial", Font.BOLD,40));
		pd.setForeground(Color.WHITE);
		cp.add(pd);
		
		JLabel fn = new JLabel("First Name");
		fn.setBounds(100, 110, 150, 40);
		fn.setFont(new Font("Arial", Font.BOLD,20));
		fn.setForeground(Color.WHITE);
		cp.add(fn);
		
		fnta.setBounds(220, 115, 400, 25);
		fnta.setFont(new Font("Arial", Font.BOLD,20));
		cp.add(fnta);
		
		JLabel ln = new JLabel("Last Name");
		ln.setBounds(100, 180, 150, 40);
		ln.setFont(new Font("Arial", Font.BOLD,20));
		ln.setForeground(Color.WHITE);
		cp.add(ln);
		
		lnta.setBounds(220, 185, 400, 25);
		lnta.setFont(new Font("Arial", Font.BOLD,20));
		cp.add(lnta);
		
		JLabel mob = new JLabel("Mobile");
		mob.setBounds(100, 250, 150, 40);
		mob.setFont(new Font("Arial", Font.BOLD,20));
		mob.setForeground(Color.WHITE);
		cp.add(mob);
		
		mobta.setBounds(220, 255, 400, 25);
		mobta.setFont(new Font("Arial", Font.BOLD,20));
		cp.add(mobta);
		
		JLabel email = new JLabel("Email");
		email.setBounds(100, 320, 150, 40);
		email.setFont(new Font("Arial", Font.BOLD,20));
		email.setForeground(Color.WHITE);
		cp.add(email);
		
		emailta.setBounds(220, 325, 400, 25);
		emailta.setFont(new Font("Arial", Font.BOLD,20));
		cp.add(emailta);
		
		op.setVisible(false);
		
		JLabel apt = new JLabel("Apartment");
		apt.setBounds(850, 110, 110, 40);
		apt.setFont(new Font("Arial", Font.BOLD,20));
		apt.setForeground(Color.WHITE);
		cp.add(apt);
		
		aptta.setBounds(970, 115, 400, 25);
		aptta.setFont(new Font("Arial", Font.BOLD,20));
		cp.add(aptta);
		
		JLabel st = new JLabel("Street");
		st.setBounds(850, 180, 110, 40);
		st.setFont(new Font("Arial", Font.BOLD,20));
		st.setForeground(Color.WHITE);
		cp.add(st);
		
		stta.setBounds(970, 185, 400, 25);
		stta.setFont(new Font("Arial", Font.BOLD,20));
		cp.add(stta);
		
		JLabel city = new JLabel("City");
		city.setBounds(850, 250, 110, 40);
		city.setFont(new Font("Arial", Font.BOLD,20));
		city.setForeground(Color.WHITE);
		cp.add(city);
		
		cityta.setBounds(970, 255, 140, 25);
		cityta.setFont(new Font("Arial", Font.BOLD,20));
		cp.add(cityta);
		
		JLabel state = new JLabel("State");
		state.setBounds(1180, 250, 110, 40);
		state.setFont(new Font("Arial", Font.BOLD,20));
		state.setForeground(Color.WHITE);
		cp.add(state);
		
		stateta.setBounds(1240, 255, 130, 25);
		stateta.setFont(new Font("Arial", Font.BOLD,20));
		cp.add(stateta);
		
		JLabel zc = new JLabel("Zip Code");
		zc.setBounds(1140, 320, 110, 40);
		zc.setFont(new Font("Arial", Font.BOLD,20));
		zc.setForeground(Color.WHITE);
		cp.add(zc);
		
		zcta.setBounds(1240, 325, 130, 25);
		zcta.setFont(new Font("Arial", Font.BOLD,20));
		cp.add(zcta);
		
		JLabel country = new JLabel("Country");
		country.setBounds(850, 320, 110, 40);
		country.setFont(new Font("Arial", Font.BOLD,20));
		country.setForeground(Color.WHITE);
		cp.add(country);
		
		countryta.setBounds(970, 325, 140, 25);
		countryta.setFont(new Font("Arial", Font.BOLD,20));
		cp.add(countryta);
		
		
		
		cc.setBounds(850, 520, 200, 50);
		cc.setForeground(Color.WHITE);
		cc.setOpaque(false);
		cc.setFont(new Font("Arial", Font.BOLD,25));
		cp.add(cc);
		
		dc.setBounds(850, 570, 200, 50);
		dc.setForeground(Color.WHITE);
		dc.setOpaque(false);
		dc.setFont(new Font("Arial", Font.BOLD,25));
		cp.add(dc);
		
		ppl.setBounds(850, 620, 200, 50);
		ppl.setForeground(Color.WHITE);
		ppl.setOpaque(false);
		ppl.setFont(new Font("Arial", Font.BOLD,25));
		cp.add(ppl);
		
		cod.setBounds(850, 670, 300, 50);
		cod.setForeground(Color.WHITE);
		cod.setOpaque(false);
		cod.setFont(new Font("Arial", Font.BOLD,25));
		cp.add(cod);
		
		pdbg.add(cc);
		pdbg.add(dc);
		pdbg.add(ppl);
		pdbg.add(cod);
		
		po.setBounds(1350, 750, 160, 50);
		po.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(po);
		po.addActionListener(act);
		
		logout.setBounds(1400,30,120,30);
		logout.setFont(new Font("Arial",Font.BOLD,15));
		cp.add(logout);
		logout.addActionListener(act);
		
		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/bg4.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		setVisible(true);
		
	}
	
	class Action implements ActionListener
	{	
		public void actionPerformed(ActionEvent act) 
		{
			if(act.getSource()==logout)
			{
				JLabel msg18= new JLabel("DO YOU WANT TO LOGOUT?");
				msg18.setFont(new Font("Arial",Font.BOLD,15));
				int lg = JOptionPane.showConfirmDialog(null, msg18,"QUESTION",JOptionPane.YES_NO_OPTION);
				
				if(lg==JOptionPane.YES_OPTION)
				{
					LoginPage lpg = new LoginPage();
					lpg.setVisible(true);
					setVisible(false);
				}
			}
			
			if(act.getSource()==po)
			{
				int c1=0, c2=0, c3=0, c4=0, c5=0, c6=0, c7=0, c8=0, c9=0, c10=0,ct=0;
				String a1 = fnta.getText(), a2 = lnta.getText(), a3 = mobta.getText(), a4 = emailta.getText(), a5 = aptta.getText(), a6 = stta.getText(), a7 = cityta.getText(), a8 = stateta.getText(), a9 = zcta.getText(), a10 = countryta.getText();
			
				for(int i=0; i<a1.length();i++)
				{ if(a1.charAt(i) == ' ')
						c1++; }
				
				for(int i=0; i<a2.length();i++)
				{ if(a2.charAt(i) == ' ')
						c2++; }
				
				for(int i=0; i<a3.length();i++)
				{ if(a3.charAt(i) == ' ')
						c3++; }
				
				for(int i=0; i<a4.length();i++)
				{ if(a4.charAt(i) == ' ')
						c4++; }
				
				for(int i=0; i<a5.length();i++)
				{ if(a5.charAt(i) == ' ')
						c5++; }
				
				for(int i=0; i<a6.length();i++)
				{ if(a6.charAt(i) == ' ')
						c6++; }
				
				for(int i=0; i<a7.length();i++)
				{ if(a7.charAt(i) == ' ')
						c7++; }
				
				for(int i=0; i<a8.length();i++)
				{ if(a8.charAt(i) == ' ')
						c8++; }
				
				for(int i=0; i<a9.length();i++)
				{ if(a9.charAt(i) == ' ')
						c9++; }
				
				for(int i=0; i<a10.length();i++)
				{ if(a10.charAt(i) == ' ')
						c10++; }
				
				if(c1==a1.length() || a1.length()==0 || c2==a2.length() || a2.length()==0 )
				{ 	JLabel msg1 = new JLabel("NAME MISSING. PLEASE CHECK FIRST & LAST NAME");
					msg1.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg1,"ERROR",JOptionPane.ERROR_MESSAGE); 
					ct++;	}
				
				else if(c3==a3.length() || a3.length()!=10 )
				{	JLabel msg2 = new JLabel("KINDLY ENTER A VALID 10 DIGIT MOBILE NUMBER");
					msg2.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg2,"ERROR",JOptionPane.ERROR_MESSAGE); 
					mobta.setText("");
					ct++;	}
				
				
				else if(c4==a4.length() || a4.length()==0)
				{	JLabel msg3 = new JLabel("EMAIL ADDRESS MISSING");
					msg3.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg3,"ERROR",JOptionPane.ERROR_MESSAGE); 
					ct++;	}
				
				else if(EmailValidation(a4)==false)
				{
					JLabel msg14= new JLabel("EMAIL ADDRESS IS INVALID. PLEASE PROVIDE A VALID EMAIL ADDRESS");
					msg14.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg14,"ERROR",JOptionPane.ERROR_MESSAGE);
					emailta.setText("");
					ct++;
				}
				
				else if(c5==a5.length() || a5.length()==0 || c6==a6.length() || a6.length()==0 || c7==a7.length() || a7.length()==0 || c8==a8.length() || a8.length()==0 || c9==a9.length() || a9.length()==0 || c10==a10.length() || a10.length()==0)
				{	JLabel msg4 = new JLabel("PLEASE CHECK ADDRESS DETAILS");
					msg4.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg4,"ERROR",JOptionPane.ERROR_MESSAGE);
					ct++;	}
				
				else if(pdbg.getSelection()==null)
				{	JLabel msg5 = new JLabel("PLEASE SELECT A PAYMENT OPTION");
					msg5.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg5,"ERROR",JOptionPane.ERROR_MESSAGE);
					ct++;	}
					
				else if(a3.length() == 10 )
				{
					try { Long.parseLong(a3);} 
					catch (NumberFormatException e) { 	JLabel msg6 = new JLabel("MOBILE FIELD MUST CONTAIN ONLY A 10 DIGIT NUMBER");
														msg6.setFont(new Font("Arial",Font.BOLD,15));
														JOptionPane.showMessageDialog(null,msg6,"ERROR",JOptionPane.ERROR_MESSAGE); 
														mobta.setText("");	ct++;	}
				}
				
				if(a9.length() > 0 )
				{
					try { Integer.parseInt(a9);} 
					catch (NumberFormatException e) {	JLabel msg7 = new JLabel("ZIP CODE SHOULD BE A 5 DIGIT NUMBER");
														msg7.setFont(new Font("Arial",Font.BOLD,15));
														JOptionPane.showMessageDialog(null,msg7,"ERROR",JOptionPane.ERROR_MESSAGE); 
														zcta.setText(""); ct++;		}
				}
				
				
				
				if(pdbg.getSelection()!=null)
				{ 
					if(cc.isSelected())
						payopt = "Credit Card";
					if(dc.isSelected())
						payopt = "Debit Card";
					if(ppl.isSelected())
						payopt = "PayPal";
					if(cod.isSelected())
						payopt = "Cash On Delivery";
				}
				
				
				if(ct==0 && EmailValidation(emailta.getText())==true)
				{
					try
					{	
						String newst = "INSERT INTO Billing (Order_No, First_name, Last_Name, Mobile, Email, Aparment, Street, City, State, Zip_Code, Country, Amount, Payment_Method) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
						Connection conn2 = db2.getConnection();
						PreparedStatement s3 = conn2.prepareStatement(newst); 
						
						s3.setString(1, Long.toString(abc.ordernumber)); 
						s3.setString(2, a1); 
						s3.setString(3, a2);
						s3.setString(4, a3);
						s3.setString(5, a4);
						s3.setString(6, a5);
						s3.setString(7, a6);
						s3.setString(8, a7);
						s3.setString(9, a8);
						s3.setString(10, a9);
						s3.setString(11, a10);
						s3.setString(12, op.pr);
						s3.setString(13, payopt);
						
						int rs3 = s3.executeUpdate();
						
						JLabel msg8 = new JLabel("ORDER PLACED SUCCESSFULLY");
						msg8.setFont(new Font("Arial",Font.BOLD,15));
						JOptionPane.showMessageDialog(null,msg8,"SUCCESS",JOptionPane.PLAIN_MESSAGE);
						
						LoginPage lp1 = new LoginPage();
						lp1.setVisible(true);
						setVisible(false);
					}
					
					catch(SQLException e)
					{
						System.out.println(e.getMessage());
					}
					
				}

			}
		}
	}

}
