package FinalProject;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.*;


public class Cakes extends JFrame
{
	DB a1 = new DB();
	OrderNumber abc = new OrderNumber();
	
	JButton continuebtn = new JButton("Continue");
	JButton checkoutbtn = new JButton("Checkout");
	JButton logout = new JButton("LOG OUT");

	JLabel pds1 = new JLabel("Pound(s)");
	JLabel pds2 = new JLabel("Pound(s)");
	JLabel pds3 = new JLabel("Pound(s)");
	
	String[] choices = { "0","1","2","3","4","5","6"};
	
	JComboBox<String> cbsz1 = new JComboBox<String>(choices);
	JComboBox<String> cbsz2 = new JComboBox<String>(choices);
	JComboBox<String> cbsz3 = new JComboBox<String>(choices);
	

	public Cakes()
	{	
		
		setExtendedState(MAXIMIZED_BOTH);
		setResizable(false);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container cp = getContentPane();
		Action act = new Action();
		
		JLabel title = new JLabel("CAKES");
		title.setFont(new Font("Lucida Calligraphy",Font.ITALIC,80));
		title.setForeground(Color.BLUE);
		title.setBounds(570,0,1100,150);
		cp.add(title);
		
		JLabel cake1name = new JLabel("COSMIC CAKE");
		cake1name.setBounds(150, 170, 250, 20);
		cake1name.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(cake1name);
		
		ImageIcon img = new ImageIcon("src/Cake1.jpg");
		JLabel cake1 = new JLabel(img);
		cake1.setBounds(80, 200, 300, 225);
		cp.add(cake1);
		
		JLabel cake1size = new JLabel("Size");
		cake1size.setBounds(130, 455, 80, 20);
		cake1size.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(cake1size);
		
		cbsz1.setBounds(200, 450, 50, 30);
		cbsz1.setFont(new Font("Arial",Font.PLAIN,20));
		cp.add(cbsz1);
		
		pds1.setBounds(260, 455, 100, 20);
		pds1.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(pds1);
		
		JLabel cake2name = new JLabel("RAINBOW CAKE");
		cake2name.setBounds(640, 170, 300, 20);
		cake2name.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(cake2name);
		
		ImageIcon img2 = new ImageIcon("src/Cake2.jpg");
		JLabel cake2 = new JLabel(img2);
		cake2.setBounds(570, 200, 300, 225);
		cp.add(cake2);
		
		JLabel cake2size = new JLabel("Size");
		cake2size.setBounds(620, 455, 80, 20);
		cake2size.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(cake2size);
		
		cbsz2.setBounds(690, 450, 50, 30);
		cbsz2.setFont(new Font("Arial",Font.PLAIN,20));
		cp.add(cbsz2);
		
		pds2.setBounds(750, 455, 100, 20);
		pds2.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(pds2);
		
		
		
		JLabel cake3name = new JLabel("DEATH BY CHOCOLATE");
		cake3name.setBounds(1060, 170, 300, 20);
		cake3name.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(cake3name);
		
		ImageIcon img3 = new ImageIcon("src/Cake3.jpg");
		JLabel cake3 = new JLabel(img3);
		cake3.setBounds(1020, 200, 300, 225);
		cp.add(cake3);
		
		JLabel cake3size = new JLabel("Size");
		cake3size.setBounds(1070, 455, 80, 20);
		cake3size.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(cake3size);
		
		cbsz3.setBounds(1140, 450, 50, 30);
		cbsz3.setFont(new Font("Arial",Font.PLAIN,20));
		cp.add(cbsz3);
		
		pds3.setBounds(1200, 455, 100, 20);
		pds3.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(pds3);
		
		logout.setBounds(1400,30,120,30);
		logout.setFont(new Font("Arial",Font.BOLD,15));
		cp.add(logout);
		logout.addActionListener(act);
		
		continuebtn.setBounds(1300, 700, 150, 40);
		continuebtn.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(continuebtn);
		continuebtn.addActionListener(act);
		
		checkoutbtn.setBounds(1300, 760, 150, 40);
		checkoutbtn.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(checkoutbtn);
		checkoutbtn.addActionListener(act);
		
		
		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/bg.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		setVisible(true);
	}
	
	class Action implements ActionListener
	{	
		public void actionPerformed(ActionEvent act) 
		{
			if (act.getSource()==continuebtn)
			{
				DBVal a2 = new DBVal();
				a2.OrderInfo(cbsz1, "C1"); a2.OrderInfo(cbsz2, "C2"); a2.OrderInfo(cbsz3, "C3");
				
				Menu mnu = new Menu();
				mnu.setVisible(true);
				setVisible(false);
			}
			
			if(act.getSource()==checkoutbtn)
			{
				DBVal a2 = new DBVal();
				a2.OrderInfo(cbsz1, "C1"); a2.OrderInfo(cbsz2, "C2"); a2.OrderInfo(cbsz3, "C3");
				
				OrderPreview a3 = new OrderPreview(Long.toString(abc.ordernumber));
				a3.setVisible(true);
				setVisible(false);
			}
			
			if(act.getSource()==logout)
			{
				JLabel msg20= new JLabel("DO YOU WANT TO LOGOUT?");
				msg20.setFont(new Font("Arial",Font.BOLD,15));
				int lg = JOptionPane.showConfirmDialog(null, msg20,"QUESTION",JOptionPane.YES_NO_OPTION);
				
				if(lg==JOptionPane.YES_OPTION)
				{
					LoginPage lpg = new LoginPage();
					lpg.setVisible(true);
					setVisible(false);
				}
			}
		}
	}
		
	
	
	
	public static void main(String[] args) 
	{
	 new Cakes();	 
	}

}
