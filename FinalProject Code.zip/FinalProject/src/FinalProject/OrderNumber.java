package FinalProject;

import java.time.*;
import java.time.format.DateTimeFormatter;

public class OrderNumber extends DateTime
{
	static long ordernumber = DateTime.dt;
	
	public static void main()
	{
	}

}
