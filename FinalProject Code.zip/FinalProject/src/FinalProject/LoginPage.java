package FinalProject;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginPage extends JFrame
{
	DB db1 = new DB();

	JButton login = new JButton("Login");
	JButton guest = new JButton("Guest");
	JButton ca = new JButton("Create Account");
	JButton track = new JButton("Track Order");
	
	JPasswordField pfpwd = new JPasswordField();
	JTextArea taname = new JTextArea();
	
	public LoginPage()
	{
		setExtendedState(MAXIMIZED_BOTH);
		setResizable(false);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
		Container cp = getContentPane();
		Action act = new Action();
		
		JLabel fttitle = new JLabel("Pans Cake Shop");
		fttitle.setBounds(540, 220, 600, 100);
		fttitle.setFont(new Font("Lucida Calligraphy",Font.BOLD,60));
		fttitle.setForeground(Color.WHITE);
		cp.add(fttitle);
		
		JLabel name = new JLabel("User Name");
		name.setBounds(630, 370, 110, 30);
		name.setFont(new Font("Arial",Font.BOLD,20));
		name.setForeground(Color.WHITE);
		cp.add(name);
		
		JLabel pwd = new JLabel("Password");
		pwd.setBounds(630, 410, 110, 30);
		pwd.setForeground(Color.WHITE);
		pwd.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(pwd);
		
		JLabel nu = new JLabel("New User");
		nu.setBounds(680, 560, 100, 30);
		nu.setForeground(Color.WHITE);
		nu.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(nu);
		
		taname.setBounds(750, 370, 250, 30);
		taname.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(taname);
		
		pfpwd.setBounds(750, 410, 250, 30);
		pfpwd.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(pfpwd);
		
		login.setBounds(630, 460, 110, 30);
		login.setFont(new Font("Arial",Font.BOLD,15));
		cp.add(login);
		login.addActionListener(act);
		
		
		guest.setBounds(750, 460, 110, 30);
		guest.setFont(new Font("Arial",Font.BOLD,15));
		cp.add(guest);
		guest.addActionListener(act);
		
		track.setBounds(870, 460, 130, 30);
		track.setFont(new Font("Arial",Font.BOLD,15));
		cp.add(track);
		track.addActionListener(act);
		
		ca.setBounds(800, 560, 150, 30);
		ca.setFont(new Font("Arial",Font.BOLD,15));
		cp.add(ca);
		ca.addActionListener(act);
		
		
		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/loginimg.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		setVisible(true);
		
	}
	public static void main(String[] args) 
	{
		new LoginPage();
	}
	
	class Action implements ActionListener
	{
		public void actionPerformed(ActionEvent act) 
		{
			if(act.getSource()==guest)
			{
				DateTime dtym = new DateTime();
				
				Menu menu = new Menu();
				menu.setVisible(true);
				setVisible(false);
				
			}
			
			if(act.getSource()==ca)
			{
				CreateAccount a = new CreateAccount();
				a.setVisible(true);
				setVisible(false);
				
			}
			
			if(act.getSource()==track)
			{
				OrderTrack a = new OrderTrack();
				a.setVisible(true);
				setVisible(false);
			}
			
			if(act.getSource()==login)
			{
				try 
				{
					int count=0;
					String qry = "SELECT * FROM Authorisation WHERE UserID = ? AND Password=?";
					Connection c1 = db1.getConnection();
					PreparedStatement s1 = c1.prepareStatement(qry);
					s1.setString(1, taname.getText());
					s1.setString(2, pfpwd.getText());
					ResultSet rs = s1.executeQuery();
					
					while(rs.next())
					{
						count++;
						JLabel msg9= new JLabel("SIGN IN SUCCESSFUL");
						msg9.setFont(new Font("Arial",Font.BOLD,15));
						JOptionPane.showMessageDialog(null,msg9,"Success",JOptionPane.PLAIN_MESSAGE);
						DateTime dtym = new DateTime();
						Menu orderpage = new Menu();
						orderpage.setVisible(true);
						setVisible(false);
						break;
					}
					
					if(count==0)
					{
						JLabel msg10= new JLabel("USER ID & PASSWORDS DO NOT MATCH");
						msg10.setFont(new Font("Arial",Font.BOLD,15));
						JOptionPane.showMessageDialog(null,msg10,"Error",JOptionPane.ERROR_MESSAGE);
						taname.setText("");pfpwd.setText("");
					}
					
					c1.close();
				}
				
				catch(SQLException e)
				{
					System.out.println("\nSQL Failed\n"+e.getMessage());
				}
			}
		}
	}

}
