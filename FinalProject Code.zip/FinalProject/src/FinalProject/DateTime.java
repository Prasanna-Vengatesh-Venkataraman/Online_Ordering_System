package FinalProject;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateTime 
{
	static long dt;
	
	public static void main(String[] args) 
	{
		new DateTime();
	}
	
	public DateTime()
	{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");  
		LocalDateTime now = LocalDateTime.now();
		dt = (Long.parseLong(dtf.format(now))*1000)+1;
	}

}
